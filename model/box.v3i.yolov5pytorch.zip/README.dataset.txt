# box > 2025-12-22 5:03pm
https://universe.roboflow.com/ssafy-ib7mc/box-ipx2p

Provided by a Roboflow user
License: CC BY 4.0

