# license_plate_2 > 2025-12-18 1:20am
https://universe.roboflow.com/ssafy-ib7mc/license_plate_2-edslp

Provided by a Roboflow user
License: CC BY 4.0

